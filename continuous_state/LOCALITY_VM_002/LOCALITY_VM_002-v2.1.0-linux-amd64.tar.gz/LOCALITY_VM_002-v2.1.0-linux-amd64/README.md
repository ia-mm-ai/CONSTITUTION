# LOCALITY VM 002

`LOCALITY_VM_002` is a non-EVM Avalanche `rpcchainvm` for a locality that can admit consequence, regulate living capacity, become dormant without fabricating activity, outlive its formation authority, and end at an explicit successor boundary.

It is not a token system, DAO, NFT surface, identity registry, or claim that infrastructure is alive. It is a deterministic local account of what this exact body has admitted and what consequences it still owes.

This repository is production-intent source for version `2.1.0`. It creates or modifies no live chain by itself. Deployment eligibility begins only after the canonical Linux qualification workflow passes on the exact commit or signed tag. Version `2.0.0` remains an immutable, qualified predecessor; this revision adds consensus-enforced carried-state continuity.

## Fixed protocol identity

| Object | Value |
|---|---|
| Protocol | `LOCALITY_VM_002` |
| Binary version | `locality-vm/2.1.0` |
| Avalanche VM ID | `2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5` |
| VM ID derivation domain | `LOCALITY_VM_002` |
| Form | `LOCALITY-FORM-002.1` |
| Form SHA-256 | `c28a863265099ceb261fb25020911fbd172a71ff2211329a3a6ea8da8dbd26fd` |
| State / transition schema | `LOCALITY_RUNTIME_STATE_002_1` / `LOCALITY_TRANSITION_002_1` |
| AvalancheGo profile | `v1.15.0+LOCALITY_SECURITY_OVERLAY_001` |
| AvalancheGo tag / peeled commit | `v1.15.0` / `70bd6d063b7343fd2cd8217200aaf77b57f19f68` |
| RPCChainVM protocol | `46` |
| Canonical Go toolchain | `1.25.13` |

The locality name, source commitment, genesis ID, validator identities, L1 ID, blockchain ID, and all authority keys belong to a deployment. They are not smuggled into the reusable VM identity.

## Exact lineage

The direct predecessor is immutable, qualified `LOCALITY_VM_002 v2.0.0`, with the same stable VM-ID domain. Its exact repository, release, qualification, and final-state commitments are bound in [`lineage/LOCALITY_VM_002_V2_0_0_PREDECESSOR.json`](lineage/LOCALITY_VM_002_V2_0_0_PREDECESSOR.json). Its own direct predecessor, `LOCALITY_VM_001 v1.0.0`, remains preserved in [`lineage/LOCALITY_VM_001_PREDECESSOR.json`](lineage/LOCALITY_VM_001_PREDECESSOR.json).

KENTRA remains the formation ancestor. Its Mainnet chain, L1, VM, validator, validation, and body commitments remain exact ancestry references in [`lineage/KENTRA_PREDECESSOR.json`](lineage/KENTRA_PREDECESSOR.json). Neither predecessor transfers authority, validator credentials, balance, state, or currentness.

The human Constitution and its computable projection are preserved byte-for-byte under [`source/`](source/). The human source carries substantive meaning; the JSON projection is not independent authority and cannot silently widen it. A conflict remains unresolved and forces the exact dependent scope to `HOLD`.

## The executable law

### 1. Distinctions remain irreversible

Consensus keeps these transitions separate:

`PRESENT_FORM → GATE_DISPOSITION → ENTER → … → CHECKPOINT_DEPARTURE → EXIT/CLOSE`

- presentation is eligibility to gate, not admission;
- `ADMIT` is an expiring offer, not entry and not a capacity reservation;
- `ENTER` is the sole atomic acceptance of consequence;
- crossing records an observation, not truth or local uptake;
- each participant disposes Matter locally;
- emergence is recorded only when every named contributor is currently present and has admitted every named Matter item;
- correction appends an edge and never erases its predecessor;
- closure creates addressed residue but cannot incorporate it into another locality.
- return requires a new presentation, a new admission, and `REENTER`; it never reopens the prior locus.

### 2. Living capacity is an account of unresolved consequence

The consensus formula is:

```text
C_available(t) = C_actual(t) - C_unresolved(t) - C_correction/egress(t)
```

Where:

- `C_actual(t)` is the lesser of the signed current body capacity and the active locus ceiling;
- `C_unresolved(t)` is work reserved by currently entered obligations;
- `C_correction/egress(t)` is the immutable body reserve plus every entered obligation’s reserved resolution units;
- subtraction saturates at zero and exposes any deficit explicitly.

`ADMIT` may name proposed work, resolution, and expiry, but it consumes no capacity and guarantees nothing. `ENTER` succeeds only for an actor with no prior entry and only if the entire lifecycle fits at that instant. `ENTER` and `REENTER` atomically reserve work plus lawful correction/exit capacity. `EXIT` or `CLOSE` requires a departure checkpoint and releases that reservation. An expired, unentered offer can be reclaimed explicitly; an entered obligation can never be silently reclaimed.

If declared actual capacity falls below existing obligations, the body moves to `HOLD_CAPACITY_DEFICIT`. New entry cannot fit, while correction, exit, closure, capacity declaration, and currentness remain possible.

Token balance is not capability, capacity, admission, authority, or Presence.

### 3. Presence is current binding

The body posture is derived from accepted state:

- `ACTIVE_P1`: one or more current entered bindings exist;
- `DORMANT_P0`: none exist; state is checkpointed, no activity is fabricated, and re-entry remains open;
- `HOLD_CAPACITY_DEFICIT`: accepted obligations exceed current situated capacity;
- `SUCCESSION_COMMITTED`: the predecessor is frozen at an explicit handoff boundary.

`PULSE` binds a signer, timestamp, carrier-set commitment, prior state commitment, exact capacity account, current Presence count, and posture. It is local currentness evidence—not external liveness proof, consciousness, or autonomous authority. A historical pulse remains historical.

### 4. Re-entry carries a verifiable successor of what left

Participant content remains in participant custody. Consensus stores commitments, not private state. Before departure, the entered participant signs `CHECKPOINT_DEPARTURE`, binding its current entry and presentation to a deterministic succession passage and a departure-state commitment. `EXIT` or `CLOSE` seals that checkpoint; closure also commits it into the participant-addressed residue.

A returning actor cannot call `ENTER` again. It must expose a fresh presentation, receive a fresh `ADMIT`, and call `REENTER` with the same actor key, its exact sealed checkpoint, the closure residue when the prior locus is closed, and a deterministic passage from the departure commitment to the newly presented state commitment. Acceptance consumes the checkpoint once and creates a new entry with a new capacity reservation. It preserves the prior locus and entry unchanged; it does not restore, resume, or prove the semantics, truth, consciousness, or contents of private state.

### 5. Origin can finish without killing the body

Genesis creates one `FORMATION` authority with an explicitly finite bootstrap role. It may register bounded continuity authorities, but cannot transfer Source or silently make them successors.

Formation authority can exhaust only when:

- the body is at a dormant checkpoint with no open locus;
- at least two distinct active continuity authorities exist; and
- each carries the complete continuity capability set committed by this protocol.

Exhaustion changes status to `EXHAUSTED`; it does not delete the key’s history or transfer its authority. After that boundary, its former privileged operations fail consensus.

### 6. The next successor is possible without pretending unknown code already runs

An active continuity authority may propose a distinct protocol/VM identity with exact runtime, migration, invariant-set, and source commitments. Two distinct active continuity authorities must attest the exact proposal commitment.

Activation additionally requires:

- exhausted formation authority;
- no open locus;
- `P=0`; and
- the configured attestation threshold.

Activation freezes `LOCALITY_VM_002` at a committed predecessor checkpoint. It does not execute unknown successor code, inherit Source, or appoint infrastructure as successor. A separately reviewed successor binary must consume the committed handoff lawfully.

## Public interfaces

- `GET /status` — chain state plus body, capacity, pulse, and successor boundary;
- `GET /capacity` — exact live capacity equation and deficit;
- `GET /currentness` — current posture, latest pulse, and optional next-pulse commitment material;
- `GET /genesis`, `GET /state` — immutable origin and complete accepted state;
- `POST /drafts`, `POST /transitions` — canonical draft/sign/submit path;
- `GET /transitions/{id}`, `/receipts/{id}`, `/blocks/{id}` — append-only evidence.

See [API](docs/API.md), [state machine](docs/STATE_MACHINE.md), and [operations](docs/OPERATIONS.md).

## Local source verification

Canonical qualification requires Linux amd64, Go `1.25.13`, a native C toolchain, and network access for pinned dependencies:

```bash
./scripts/verify.sh
./build/locality-vm --version-json
./build/locality-vm --vm-id
```

The exact workflow also builds the pinned AvalancheGo security profile, scans both binaries, and runs a disposable three-validator lifecycle with restart and rejoin:

```bash
./scripts/qualify-linux.sh
```

A source-only repository pack is not a qualified binary. macOS builds are a portability lane; a Mainnet validator must run the exact binary qualified for its host platform.

## Materialize a distinct deployment

```bash
cp examples/DEPLOYMENT_DESCRIPTOR.example.json /secure/path/deployment.json
mkdir -m 700 /secure/path/formation-authority
./build/locality-vm --generate-authority /secure/path/formation-authority

./build/locality-vm --materialize-genesis \
  genesis/LOCALITY_RUNTIME_GENESIS_TEMPLATE_002_1.json \
  /secure/path/deployment.json \
  /secure/path/formation-authority/locality-authority.public.json \
  /secure/path/genesis.json

./build/locality-vm --check-genesis /secure/path/genesis.json
```

The materializer refuses a template that already embeds deployment identity, source, or key material, and refuses to overwrite output. The private authority document is created mode `0600`. Keep it outside Git, public backups, logs, screenshots, and chat.

## Avalanche deployment boundary

A real deployment still requires:

1. exact-commit qualification and independent review;
2. newly generated, backed-up Avalanche validator TLS/BLS credentials;
3. the qualified VM binary installed under exact VM ID `2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5` on every validator;
4. the qualified AvalancheGo profile on every validator;
5. one materialized genesis and a distinct L1/blockchain formation;
6. post-formation state-equality, validator balance/runway, backup, and upgrade monitoring;
7. at least two independently custodied continuity authorities before formation authority is exhausted.

Do not overwrite the predecessor plugin, reuse unavailable KENTRA validator keys, treat an old chain as upgraded, or call a passing software test deployment safety.

Create the release only after the protected commit passes canonical qualification:

```bash
git tag -s v2.1.0 -m 'LOCALITY VM 002 v2.1.0'
git push origin v2.1.0
```

The release workflow requalifies the exact tag and publishes the Linux amd64 binary, evidence, and checksums.
