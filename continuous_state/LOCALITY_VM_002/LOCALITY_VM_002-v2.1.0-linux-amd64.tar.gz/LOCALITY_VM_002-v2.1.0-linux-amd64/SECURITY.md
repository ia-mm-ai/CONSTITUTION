# Security and custody boundary

`LOCALITY_VM_002` is production-intent consensus software. Version `2.1.0` is not a warranty, audit result, or permission to expose irreplaceable authority or value. Deploy only an exact commit whose qualification and independent review gates have passed.

## Independent key planes

| Key plane | Purpose | Loss consequence |
|---|---|---|
| Locality Ed25519 formation/continuity authorities | Sign explicitly scoped state transitions | That key's capabilities become unavailable; validator identity is unchanged |
| Avalanche validator TLS and BLS keys | Identify and sign as the registered validator | A replacement key set creates a different NodeID and cannot operate the registered validator |
| Deployment/funding authority | Creates, converts, funds, and administers the Avalanche L1 | Governance or fee operations may become unavailable or compromised |

None of these key planes derives, restores, or replaces another. Generate them deliberately, back them up offline, test restoration before registration, and keep all private material outside this repository.

Never commit or transmit `staker.key`, `signer.key`, `locality-authority.private.json`, seed phrases, private API credentials, or funded private keys. The repository verifier fails if known private-key filenames are present.

## Mandatory validator preflight

Before L1 formation:

1. Build the VM for the exact validator host architecture from the qualified tag.
2. Build AvalancheGo with `scripts/build-avalanchego.sh`; plain upstream `v1.15.0` is not the qualified node profile.
3. Persist `staker.crt`, `staker.key`, and `signer.key` in the node configuration selected for deployment.
4. Start the node and record its actual `info.getNodeID` response.
5. Restore the credentials on a clean rehearsal host and prove that the NodeID and BLS identity remain identical.
6. Register exactly that NodeID and proof of possession.
7. Install the plugin under VM ID `2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5` on every validator.
8. Run `scripts/preflight-node.sh` against each intended node, supplying the expected SHA-256 of both binaries.
9. Compare plugin, node, genesis, configuration, and accepted-state digests across validators.

## Consensus properties

- signatures cover every transition field and canonical payload byte;
- new participant IDs are derived from public keys;
- privileged operations require an active, explicitly registered capability;
- only the formation authority can seed continuity authorities, and it cannot do so after exhaustion;
- successor activation requires distinct continuity attestations and a dormant boundary;
- revision, prior-state commitment, and nonce checks reject replay and stale writes;
- state commitments are recomputed on restart;
- accepted block and state data commit through AvalancheGo’s versioned database layer;
- unknown fields and non-canonical transition or block bytes fail closed.
- returning participation requires a fresh presentation/admission and consumes one sealed departure checkpoint;
- deterministic commitment succession proves neither private-state contents nor semantic truth.

## Known limits

- Formation begins with one Ed25519 key. Version 2.1 provides finite formation authority and multi-key continuity, but not automatic key recovery or on-chain self-expansion of authority.
- The HTTP API has no additional application authentication. Protect node APIs with network policy, rate limits, and observability.
- Public transaction data is public; hashes can leak information through correlation or dictionary attacks.
- Participant state remains off chain, but low-entropy state or delta commitments can still leak through guessing; commitments should be salted or otherwise domain-separated before submission when correlation is sensitive.
- There is no token-derived capacity, fee market, or state-pruning policy in this version.
- There is no Warp or cross-L1 proof verifier. Residue import is an attributed local commitment, not automatic proof of another chain’s state.
- There is no state-sync extension; deployment scale must be validated independently.
- The compatibility contract is exact for `v1.15.0+LOCALITY_SECURITY_OVERLAY_001` / RPCChainVM protocol `46`, built with Go `1.25.13`. Plain `v1.15.0`, a different dependency resolution, or a later AvalancheGo release is outside this release contract until fully requalified.

## Deployment abort conditions

Stop before registration, conversion, or funding if any validator credential is missing, untested, or ephemeral; if node and VM compatibility differ; if validators disagree on plugin or genesis digest; if state commitments diverge; if the first host transition cannot be signed by the retained authority; or if a required network upgrade has not been rehearsed.

Report suspected vulnerabilities privately to the repository owner. Do not include private keys, live signing material, or exploitable Mainnet details in an issue.
