# Lineage boundary

`LOCALITY_VM_002 v2.1.0` is an additive revision of the stable protocol identity. It preserves every predecessor without rewriting, renaming, or pretending to continue a deployed chain state.

## Direct predecessor

`LOCALITY_VM_002 v2.0.0` is the direct, immutable software predecessor:

- VM ID: `2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5`
- repository pack SHA-256: `6abe4b6914075afbdb1a1a8be87f24b21abe8198b712ca603ed62fe475e7137f`
- Linux amd64 release SHA-256: `e964d0587a7bd97b1af6dc8f69dc3c7faac345b2e82a5eeaca58adcc35a8faa3`
- qualification evidence SHA-256: `2adcb6765580e0fff6b92db3e574ebe36abb870c48b9333b4e8d79cb62d26a4d`
- final qualified state commitment: `2dcae5d702fbc0e01d0c7d1221f7d1c4da3479b66a38c76df14cd7c0d9e36aaa`

Its complete record is [`lineage/LOCALITY_VM_002_V2_0_0_PREDECESSOR.json`](lineage/LOCALITY_VM_002_V2_0_0_PREDECESSOR.json). It was qualified but not deployed by the current operator, so this revision requires a fresh genesis rather than mutating a live v2.0 chain. The deeper `LOCALITY_VM_001 v1.0.0` record remains intact in [`lineage/LOCALITY_VM_001_PREDECESSOR.json`](lineage/LOCALITY_VM_001_PREDECESSOR.json).

## Formation ancestor

KENTRA remains the historical formation ancestor. Its Avalanche Mainnet IDs and body commitment are preserved in [`lineage/KENTRA_PREDECESSOR.json`](lineage/KENTRA_PREDECESSOR.json). The registered validator cannot be operated by the current custodian because its original Avalanche TLS and BLS private keys are unavailable. That is an operational boundary, not deletion of the historical chain.

## What does not cross

No predecessor key, validator credential, token balance, authority, accepted state, or currentness crosses into a deployment of `LOCALITY_VM_002 v2.1.0`. Every deployment requires a new genesis identity, source commitment, formation authority, retained validator credentials, L1, and blockchain.

The inherited matter is explicit ancestry plus deliberately re-embodied invariants. Version `2.1.0` additionally makes participant departure/re-entry continuity executable through signed state commitments; that is a runtime participant passage, not migration of predecessor chain state. Succession is a recorded relation, not ownership or identity inheritance.
