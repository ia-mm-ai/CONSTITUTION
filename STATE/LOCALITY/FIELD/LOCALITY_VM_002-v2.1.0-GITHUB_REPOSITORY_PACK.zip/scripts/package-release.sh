#!/usr/bin/env bash
set -euo pipefail

root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
output_dir="${1:-${root_dir}/artifacts/release}"
qualification_dir="${2:-}"
version="2.1.0"
go_binary="${GO_BINARY:-go}"

if [[ -e "${output_dir}" ]]; then
  echo "refusing to overwrite release output: ${output_dir}" >&2
  exit 1
fi
mkdir -p "${output_dir}"
output_dir="$(cd "${output_dir}" && pwd)"
if [[ -n "${qualification_dir}" ]]; then
  if [[ ! -d "${qualification_dir}" ]]; then
    echo "qualification directory does not exist: ${qualification_dir}" >&2
    exit 1
  fi
  qualification_dir="$(cd "${qualification_dir}" && pwd)"
fi
"${root_dir}/scripts/verify.sh"

if [[ -n "${qualification_dir}" ]]; then
  if [[ ! -f "${qualification_dir}/QUALIFICATION_REPORT.json" ]]; then
    echo "qualification evidence is missing from ${qualification_dir}" >&2
    exit 1
  fi
  qualified_sha256="$(python3 -c '
import json, sys
report = json.load(open(sys.argv[1], encoding="utf-8"))
if report.get("result") != "PASS":
    raise SystemExit("qualification result is not PASS")
vm = report.get("vm", {})
if vm.get("protocol") != "LOCALITY_VM_002" or vm.get("version") != "2.1.0":
    raise SystemExit("qualification identity mismatch")
print(vm["binary_sha256"])
' "${qualification_dir}/QUALIFICATION_REPORT.json")"
  release_sha256="$(sha256sum "${root_dir}/build/locality-vm" | awk '{print $1}')"
  if [[ "${release_sha256}" != "${qualified_sha256}" ]]; then
    echo "release binary differs from the qualified binary" >&2
    exit 1
  fi
fi

stage="$(mktemp -d "${TMPDIR:-/tmp}/locality-vm-release-002.XXXXXX")"
cleanup() {
  case "${stage}" in
    "${TMPDIR:-/tmp}"/locality-vm-release-002.*) rm -rf -- "${stage}" ;;
    *) echo "refusing to remove unexpected release directory: ${stage}" >&2 ;;
  esac
}
trap cleanup EXIT INT TERM

package_root="${stage}/LOCALITY_VM_002-v${version}-linux-amd64"
mkdir -p \
  "${package_root}/compat" \
  "${package_root}/examples" \
  "${package_root}/genesis" \
  "${package_root}/lineage" \
  "${package_root}/profile" \
  "${package_root}/source" \
  "${package_root}/scripts"
install -m 0755 "${root_dir}/build/locality-vm" "${package_root}/locality-vm"
cp "${root_dir}/README.md" "${root_dir}/SECURITY.md" "${root_dir}/LINEAGE.md" \
  "${root_dir}/RELEASE_MANIFEST.json" "${package_root}/"
cp "${root_dir}/MANIFEST.sha256" "${package_root}/SOURCE_MANIFEST.sha256"
cp "${root_dir}/genesis/LOCALITY_RUNTIME_GENESIS_TEMPLATE_002_1.json" "${package_root}/genesis/"
cp "${root_dir}/profile/LOCALITY_FORM_002_1.json" "${package_root}/profile/"
cp "${root_dir}"/source/* "${package_root}/source/"
cp "${root_dir}/examples/DEPLOYMENT_DESCRIPTOR.example.json" "${package_root}/examples/"
cp "${root_dir}"/lineage/*.json "${package_root}/lineage/"
cp "${root_dir}/compat/AVALANCHEGO_SECURITY_OVERLAY_001.json" "${package_root}/compat/"
install -m 0755 \
  "${root_dir}/scripts/build-avalanchego.sh" \
  "${root_dir}/scripts/prepare-avalanchego.sh" \
  "${root_dir}/scripts/preflight-node.sh" \
  "${package_root}/scripts/"
GOWORK=off "${go_binary}" version -m "${package_root}/locality-vm" >"${package_root}/BUILD_INFO.txt"
(
  cd "${root_dir}"
  GOWORK=off "${go_binary}" list -m all
) >"${package_root}/DEPENDENCIES.txt"
(
  cd "${package_root}"
  find . -type f ! -name PACKAGE_SHA256SUMS -print0 | sort -z | xargs -0 sha256sum >PACKAGE_SHA256SUMS
)
(
  cd "${stage}"
  tar -czf "${output_dir}/LOCALITY_VM_002-v${version}-linux-amd64.tar.gz" \
    "$(basename "${package_root}")"
)
if [[ -n "${qualification_dir}" ]]; then
  tar -C "${qualification_dir}" -czf \
    "${output_dir}/LOCALITY_VM_002-v${version}-qualification-evidence.tar.gz" .
fi
(
  cd "${output_dir}"
  sha256sum ./*.tar.gz >SHA256SUMS
)

echo "release package: ${output_dir}"
