#!/usr/bin/env python3
"""Fail closed on LOCALITY_VM_002 repository drift before compilation or release."""

from __future__ import annotations

import ast
import hashlib
import json
import pathlib
import re
import subprocess
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]
EXPECTED_VM_ID = "2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5"
EXPECTED_FORM_SHA = "c28a863265099ceb261fb25020911fbd172a71ff2211329a3a6ea8da8dbd26fd"
EXPECTED_HUMAN_SHA = "4be24cf15d3653abcfd7ae4191246a52c22e61246b8d4d33f46b329c615596dd"
EXPECTED_MACHINE_SHA = "f9c98d4d9abd6ce373a4336f0c9cefc6c60ffdee4e414f33eb7247cb0d6e4bab"
EXPECTED_AVALANCHEGO_COMMIT = "70bd6d063b7343fd2cd8217200aaf77b57f19f68"


def fail(message: str) -> None:
    raise RuntimeError(message)


def read_json(relative: str) -> object:
    with (ROOT / relative).open("r", encoding="utf-8") as source:
        return json.load(source)


def sha256(relative: str) -> str:
    return hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()


def check_required_files() -> None:
    required = {
        ".github/workflows/qualify.yml",
        ".github/workflows/release.yml",
        "LINEAGE.md",
        "RELEASE_MANIFEST.json",
        "examples/DEPLOYMENT_DESCRIPTOR.example.json",
        "compat/AVALANCHEGO_SECURITY_OVERLAY_001.json",
        "genesis/LOCALITY_RUNTIME_GENESIS_TEMPLATE_002.json",
        "genesis/LOCALITY_RUNTIME_GENESIS_TEMPLATE_002_1.json",
        "lineage/LOCALITY_VM_001_PREDECESSOR.json",
        "lineage/LOCALITY_VM_002_V2_0_0_PREDECESSOR.json",
        "lineage/KENTRA_PREDECESSOR.json",
        "profile/LOCALITY_FORM_002.json",
        "profile/LOCALITY_FORM_002_1.json",
        "source/CONSTITUTION-01.md",
        "source/CONSTITUTION-01.json",
        "scripts/build-avalanchego.sh",
        "scripts/preflight-node.sh",
        "scripts/prepare-avalanchego.sh",
        "scripts/rehearsal-002.sh",
        "scripts/vulnerability-scan.sh",
    }
    missing = sorted(path for path in required if not (ROOT / path).is_file())
    if missing:
        fail(f"required repository files are missing: {missing}")


def check_json_documents() -> None:
    for path in sorted(ROOT.rglob("*.json")):
        if any(part in {".git", "build", "runs", "evidence"} for part in path.parts):
            continue
        with path.open("r", encoding="utf-8") as source:
            json.load(source)


def check_release_manifest() -> None:
    manifest = read_json("RELEASE_MANIFEST.json")
    release = manifest["release"]
    expected_release = {
        "protocol": "LOCALITY_VM_002",
        "version": "2.1.0",
        "binary_name": "locality-vm",
        "go_module": "locality.vm/runtime",
        "vm_id_domain": "LOCALITY_VM_002",
        "vm_id": EXPECTED_VM_ID,
        "status": "PRODUCTION_INTENT_REQUIRES_EXACT_COMMIT_QUALIFICATION",
    }
    if release != expected_release:
        fail("release identity differs from LOCALITY_VM_002 v2.1.0")
    compatibility = manifest["compatibility"]
    if compatibility["avalanchego_tag"] != "v1.15.0":
        fail("AvalancheGo tag is not v1.15.0")
    if compatibility["avalanchego_peeled_commit"] != EXPECTED_AVALANCHEGO_COMMIT:
        fail("AvalancheGo peeled commit changed")
    if compatibility["rpcchainvm_protocol"] != 46 or compatibility["go"] != "1.25.13":
        fail("toolchain compatibility target changed")
    if compatibility["avalanchego_profile"] != "v1.15.0+LOCALITY_SECURITY_OVERLAY_001":
        fail("AvalancheGo security profile changed")
    if compatibility["vulnerability_scanner"] != "golang.org/x/vuln/cmd/govulncheck@v1.7.0":
        fail("vulnerability scanner changed")
    for artifact in manifest["bound_artifacts"].values():
        if sha256(artifact["path"]) != artifact["sha256"]:
            fail(f"bound artifact digest mismatch: {artifact['path']}")


def check_genesis_boundary() -> None:
    genesis = read_json("genesis/LOCALITY_RUNTIME_GENESIS_TEMPLATE_002_1.json")
    deployment_fields = (
        genesis["domain"]["genesis_id"],
        genesis["domain"]["purpose"],
        genesis["locality"]["id"],
        genesis["locality"]["source_reference"],
        genesis["locality"]["source_sha256"],
    )
    if any(deployment_fields):
        fail("genesis template embeds a deployment-specific identity or source")
    direct = read_json("lineage/LOCALITY_VM_002_V2_0_0_PREDECESSOR.json")
    if genesis["lineage"]["direct_predecessor"] != {
        "protocol": direct["protocol"],
        "version": direct["version"],
        "vm_id": direct["vm_id"],
        "repository_pack_sha256": direct["repository_pack_sha256"],
        "linux_release_sha256": direct["linux_amd64_release_sha256"],
        "disposition": direct["disposition"],
    }:
        fail("genesis and direct predecessor record disagree")
    ancestor = read_json("lineage/KENTRA_PREDECESSOR.json")
    avalanche = ancestor["avalanche_mainnet"]
    if genesis["lineage"]["formation_ancestor"] != {
        "name": ancestor["name"],
        "blockchain_id": avalanche["blockchain_id"],
        "l1_id": avalanche["l1_id"],
        "vm_id": avalanche["vm_id"],
        "validation_id": avalanche["validation_id"],
        "validator_node_id": avalanche["validator_node_id"],
        "genesis_id": ancestor["genesis_id"],
        "body_sha256": ancestor["body_sha256"],
        "disposition": ancestor["disposition"],
        "credential_custody": ancestor["validator_credential_custody"],
        "continuation_requirement": ancestor["continuation_basis"],
    }:
        fail("genesis and KENTRA formation-ancestor record disagree")
    constitution = genesis["constitution"]
    if (
        constitution["human_sha256"] != EXPECTED_HUMAN_SHA
        or constitution["machine_sha256"] != EXPECTED_MACHINE_SHA
        or sha256(constitution["human_path"]) != EXPECTED_HUMAN_SHA
        or sha256(constitution["machine_path"]) != EXPECTED_MACHINE_SHA
    ):
        fail("genesis constitution commitments do not bind the exact source surface")
    if genesis["profile"]["form_sha256"] != EXPECTED_FORM_SHA:
        fail("genesis does not bind LOCALITY-FORM-002.1")


def check_source_identity() -> None:
    main = (ROOT / "main.go").read_text(encoding="utf-8")
    genesis = (ROOT / "genesis.go").read_text(encoding="utf-8")
    state = (ROOT / "state.go").read_text(encoding="utf-8")
    transition = (ROOT / "transition.go").read_text(encoding="utf-8")
    contracts = (
        (main, r'\bvmVersion\s*=\s*"locality-vm/2\.1\.0"', "binary version"),
        (main, r'\bvmIDDomain\s*=\s*"LOCALITY_VM_002"', "VM ID domain"),
        (genesis, EXPECTED_FORM_SHA, "form commitment"),
        (state, '"LOCALITY_RUNTIME_STATE_002_1"', "state schema"),
        (transition, '"LOCALITY_TRANSITION_002_1"', "transition schema"),
    )
    for text, pattern, label in contracts:
        if not re.search(pattern, text):
            fail(f"source {label} changed")


def check_no_private_material_or_text_drift() -> None:
    forbidden_names = {"staker.key", "signer.key", "locality-authority.private.json"}
    textual_suffixes = {".go", ".md", ".json", ".py", ".sh", ".yml", ".yaml", ".mod"}
    for path in ROOT.rglob("*"):
        if not path.is_file() or any(part in {".git", "artifacts", "build", "__pycache__", "runs", "evidence"} for part in path.parts):
            continue
        if path.name in forbidden_names or path.name.endswith(".private.json"):
            fail(f"private credential material must not be committed: {path.relative_to(ROOT)}")
        if path.suffix not in textual_suffixes:
            continue
        text = path.read_text(encoding="utf-8")
        # Constitution artifacts are byte-preserved source; their source formatting is part of the commitment.
        if path.relative_to(ROOT).parts[:1] == ("source",):
            continue
        if "\r" in text:
            fail(f"CRLF line ending in {path.relative_to(ROOT)}")
        if re.search(r"[ \t]+$", text, flags=re.MULTILINE):
            fail(f"trailing whitespace in {path.relative_to(ROOT)}")
    production_go = [path for path in ROOT.glob("*.go") if not path.name.endswith("_test.go") and path.name != "genesis.go"]
    for path in production_go:
        text = path.read_text(encoding="utf-8")
        if "KENTRA" in text or "pJHx1NU8" in text:
            fail(f"active protocol code contains formation-ancestor naming: {path.relative_to(ROOT)}")


def check_syntax_and_manifest() -> None:
    for path in sorted(ROOT.rglob("*.py")):
        if "__pycache__" not in path.parts:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    subprocess.run(
        [sys.executable, str(ROOT / "scripts/repository_manifest.py"), "--check"],
        check=True,
    )


def main() -> int:
    try:
        check_required_files()
        check_json_documents()
        check_release_manifest()
        check_genesis_boundary()
        check_source_identity()
        check_no_private_material_or_text_drift()
        check_syntax_and_manifest()
    except (KeyError, TypeError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"repository verification failed: {error}", file=sys.stderr)
        return 1
    print("LOCALITY VM 002 repository verification: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
