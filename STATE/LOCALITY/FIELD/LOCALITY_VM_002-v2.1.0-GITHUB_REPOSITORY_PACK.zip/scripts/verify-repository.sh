#!/usr/bin/env bash
set -euo pipefail

root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python_binary="${PYTHON_BINARY:-python3}"

"${python_binary}" "${root_dir}/scripts/verify_repository.py"
while IFS= read -r -d '' script; do
  bash -n "${script}"
done < <(find "${root_dir}/scripts" -maxdepth 1 -type f -name '*.sh' -print0)

echo "shell syntax verification: PASS"
