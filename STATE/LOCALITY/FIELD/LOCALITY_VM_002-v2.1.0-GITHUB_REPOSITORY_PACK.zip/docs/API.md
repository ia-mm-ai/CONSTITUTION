# HTTP API

AvalancheGo exposes these handlers under the chain route. Responses are JSON. A request body is capped at 1 MiB.

## Read state

- `GET /status` — VM compatibility, accepted height/revision/commitment, active locus, body posture, capacity, last pulse, successor boundary, pending count.
- `GET /genesis` — immutable parsed genesis plus digest and genesis block ID.
- `GET /state` — complete accepted consensus state, including append-only presentation/entry histories, departure checkpoints, and residue history.
- `GET /capacity` — current capacity equation, posture, and evidence ceiling.
- `GET /currentness` — current posture, capacity, latest pulse, and accepted state commitment.
- `GET /transitions/{transitionID}` — pending or accepted transition.
- `GET /receipts/{transitionID}` — accepted consequence receipt; absent while merely pending.
- `GET /blocks/{blockID}` — block metadata and wire block where applicable.

Optional currentness query:

```text
GET /currentness?observed_at=<unix-seconds>&carrier_set_sha256=<lowercase-sha256>
```

The response adds `next_pulse.currentness_commitment_sha256`. It is valid only for the named accepted state and before any preceding pending transition.

## Draft, sign, submit

1. `POST /drafts` with operation, actor ID/public key, locus ID, observed time, and operation payload.
2. Sign the returned exact `unsigned` object offline:

   ```bash
   ./locality-vm --sign-unsigned unsigned.json /secure/authority.private.json transition.json
   ```

3. `POST /transitions` with canonical `transition.json`.
4. Poll `GET /receipts/{transitionID}` until consensus accepts it.

Drafting changes no state. Submission returns `202 PENDING_CONSENSUS`; only block acceptance creates the receipt and consequence.

## Receipt ceiling

Every receipt returns operation, actor, locus, new revision and state commitment, derived posture, Presence count, exact capacity account, effect, and explicit non-effects. A receipt is historical evidence. It is never current Presence, external truth, consent, Source, authority transfer, or proof of another locality’s uptake.

For `CHECKPOINT_DEPARTURE`, the receipt is not an exit. For `REENTER`, the receipt proves a locally accepted, single-use commitment passage and renewed capacity reservation; it does not restore the prior locus or prove the meaning or contents of participant-held state.
