# Consensus state machine

Every accepted transition is canonical JSON, Ed25519-signed, globally revisioned, actor-nonced, and bound to the exact prior state commitment. Unknown fields, ambiguous encodings, stale revisions, stale nonces, key substitution, and predecessor mismatch fail closed.

## Body posture

Posture is derived, never declared by preference:

| Posture | Deterministic condition |
|---|---|
| `DORMANT_P0` | no current entered binding and no capacity deficit |
| `ACTIVE_P1` | at least one current entered binding and no deficit |
| `HOLD_CAPACITY_DEFICIT` | current obligations plus correction/egress reserve exceed effective actual capacity |
| `SUCCESSION_COMMITTED` | an attested successor boundary has frozen this predecessor |

`P=0` is a checkpoint, not deletion. No synthetic block or pulse is produced merely to look alive.

## Locus lifecycle

Only one locus may be open. A never-reused locus ID moves `OPEN → CLOSED`.

Within it, each participant moves through distinct state:

1. `PRESENT_FORM` records a conformant public surface.
2. `GATE_DISPOSITION` records `ADMIT`, `REFUSE`, `WITHHOLD`, or `HOLD`.
3. An `ADMIT` offer names work units, resolution units, and an expiry but reserves nothing.
4. `ENTER` checks the current offer and atomically reserves the full lifecycle, but only for an actor with no prior entry.
5. `CHECKPOINT_DEPARTURE` binds the current entry to a deterministic participant-state succession and departure commitment.
6. `EXIT` or `CLOSE` seals that checkpoint, ends current Presence, and releases the reservation.
7. Any later return requires a fresh presentation, fresh admission, and `REENTER` against the sealed checkpoint.

An expired unentered offer requires explicit `RECLAIM_ADMISSION_OFFER`. An entered reservation is not expirable and cannot be reclaimed.

## Carried-state re-entry

Private participant state is never required on chain. Each continuity step commits the participant ID, predecessor state commitment, ordered step number, and a participant-supplied delta digest; its SHA-256 is the successor state commitment. The signed passage is checked from the state commitment presented at entry to the departure commitment, and later from that departure commitment to the state commitment on the fresh return presentation.

The first passage becomes an `OPEN` departure checkpoint. `EXIT` or `CLOSE` seals it. If the locus closes, its addressed residue binds the participant, presentation, entry, checkpoint, and departure commitment. `REENTER` requires the same actor binding, an ended prior entry, a `SEALED` checkpoint, the exact residue for a closed prior locus, a fresh `ADMIT`, and adequate capacity. Acceptance marks the checkpoint `CONSUMED` and creates a new `RENEWED_ENTRY` history record.

A consumed checkpoint cannot branch into another local return. The old locus, presentation, entry, residue, and checkpoint remain append-only. This proves a signed deterministic commitment lineage only—not private content, semantic truth, identity metaphysics, consciousness, or restoration of prior progression.

## Capacity

For the active state:

```text
effective_actual = min(declared_actual, active_locus_ceiling)
unresolved = sum(work units of PRESENT entries)
correction_egress = global reserve + sum(resolution units of PRESENT entries)
available = max(0, effective_actual - unresolved - correction_egress)
deficit = max(0, unresolved + correction_egress - effective_actual)
```

`DECLARE_CAPACITY` may reduce declared actual capacity below accepted obligations because hiding loss would be false. The resulting deficit forces `HOLD`; it does not erase obligations. Correction and exit remain open.

## Matter and emergence

`OBSERVE_CROSSING` creates a Matter record with no disposition. Each entered participant or active authority may add only its own disposition. `RECORD_EMERGENCE` succeeds only when all named contributors are currently present and each has locally admitted every named Matter item.

## Correction and residue

`CORRECT` targets an existing transition attributed to the same actor and appends a replacement commitment and reason. The target event remains.

`CLOSE` requires a departure checkpoint for every present participant and creates a committed residue addressed to each participant’s presented locality. The receiver must separately execute `INCORPORATE_ADDRESSED_RESIDUE`; closure cannot perform uptake for it.

## Authority lifecycle

Genesis binds one `FORMATION` authority. It may register key-derived `CONTINUITY` authorities with explicit capability sets. No registered authority can enlarge its own set or register another authority.

`EXHAUST_FORMATION_AUTHORITY` requires a dormant checkpoint and at least the genesis minimum of fully capable continuity authorities. Exhaustion is terminal for formation privileges but preserves the historical record.

## Successor boundary

`PROPOSE_SUCCESSOR` commits a distinct protocol, VM ID, runtime, migration, invariant set, and source. `ATTEST_SUCCESSOR` appends one attestation per continuity authority. `ACTIVATE_SUCCESSOR` requires threshold attestations, exhausted formation authority, no open locus, and `P=0`.

Activation writes a handoff record and freezes all further transitions in this VM. The successor is not run inside the predecessor; unknown code cannot gain force by proposal or attestation.
