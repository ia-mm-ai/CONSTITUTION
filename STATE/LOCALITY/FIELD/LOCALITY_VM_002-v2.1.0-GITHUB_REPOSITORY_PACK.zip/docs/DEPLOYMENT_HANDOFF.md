# Avalanche deployment handoff

This handoff forms a distinct locality from `LOCALITY_VM_002 v2.1.0`; it does not mutate qualified `v2.0.0`, `LOCALITY_VM_001`, repair or rename KENTRA, or inherit any predecessor authority. All predecessors remain ancestry only.

## 1. Qualify the exact source

- Protect `main` and require the `Qualify LOCALITY VM 002` workflow.
- Review the workflow’s `QUALIFICATION_REPORT.json`, rehearsal evidence, and checksums.
- Complete every non-automated gate in [QUALIFICATION.md](QUALIFICATION.md).
- Create the signed `v2.1.0` tag only from that qualified commit.
- Use the binary produced by the release workflow, or reproduce it on the exact deployment architecture and retain the digest.
- Build the paired AvalancheGo node with `scripts/build-avalanchego.sh`; do not substitute a plain upstream `v1.15.0` binary.

## 2. Establish custody before registration

For every intended Avalanche validator, generate and persist `staker.crt`, `staker.key`, and `signer.key`. Record the resulting NodeID and BLS public key/proof of possession. Restore the credentials on a clean host and verify that the identity remains exact before any on-chain registration or funding.

Separately generate the locality Ed25519 formation authority with `locality-vm --generate-authority`. Keep the private document offline or in the deliberate signer boundary. Generate at least two independently custodied continuity authorities before planning formation-authority exhaustion. These credentials are not interchangeable.

## 3. Declare the deployment

Copy `examples/DEPLOYMENT_DESCRIPTOR.example.json` outside the repository and replace every placeholder:

- `genesis_id`: unique immutable identifier for this genesis;
- `locality_id`: unique host-locality identifier used in consensus state;
- `purpose`: bounded statement of this locality’s purpose;
- `source_reference`: deliberate source/continuity reference;
- `source_sha256`: SHA-256 of the exact source artifact being committed.

Materialize the genesis:

```bash
locality-vm --materialize-genesis \
  genesis/LOCALITY_RUNTIME_GENESIS_TEMPLATE_002_1.json \
  /secure/path/deployment.json \
  /secure/path/locality-authority.public.json \
  /secure/path/genesis.json

locality-vm --check-genesis /secure/path/genesis.json
```

Record the descriptor, public authority, genesis, and all three SHA-256 digests. Never publish the private authority file.

## 4. Install and preflight every validator

Install the exact binary as:

```text
<avalanchego-plugin-directory>/2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5
```

Then run:

```bash
./scripts/preflight-node.sh \
  http://127.0.0.1:9650 \
  2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5 \
  /absolute/plugin/directory \
  VM_BINARY_SHA256 \
  /absolute/persisted-node-key-directory \
  NodeID-EXPECTED \
  /absolute/path/to/avalanchego \
  AVALANCHEGO_BINARY_SHA256
```

Repeat on every validator. The preflight verifies both binary digests, the exact Go and gRPC security profile, the running AvalancheGo/RPC versions, retained validator credentials, private-key permissions, and the registered NodeID. Compare the genesis digest and configuration separately. Any mismatch is an abort condition.

## 5. Form a distinct Avalanche L1/blockchain

Use the then-current Avalanche CLI/API procedure to create a new chain with the materialized genesis and the fixed VM ID. Do not point the new binary at the predecessor VM ID and do not register a disposable or newly regenerated NodeID.

Before broadcasting irreversible transactions, independently review the generated transaction data, network selection, owner/control addresses, validator IDs, weights, fee mechanism, and funding source.

## 6. Prove the formed locality

After formation:

- verify the returned L1 and blockchain IDs from independent public sources;
- prove all validators bootstrap and report matching accepted state;
- execute and retain the accepted revision `0 → 1` formation transition;
- register, exercise, and restore at least two continuity authorities before exhausting formation authority;
- verify restart/rejoin on deployment infrastructure;
- monitor validator uptime, validation balance/runway, chain progress, VM health, disk, memory, API exposure, and mandatory AvalancheGo upgrades;
- test restoration again before declaring the formation complete.

Archive only public evidence with the release and deployment record. Keep every private key and recovery artifact inside its designated custody boundary.
