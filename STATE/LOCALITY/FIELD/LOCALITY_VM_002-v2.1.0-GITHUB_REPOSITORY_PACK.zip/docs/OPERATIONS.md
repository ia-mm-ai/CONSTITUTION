# Operations

All payloads are strict canonical JSON. Every digest is lowercase SHA-256 hex. `observed_at` is Unix seconds and cannot move backward relative to accepted state.

| Operation | Authorized actor | Consensus effect |
|---|---|---|
| `BOUND` | active authority with `OPEN_LOCUS` | opens one never-reused locus with a capacity ceiling |
| `PRESENT_FORM` | new or known key-derived actor | records form eligibility only |
| `GATE_DISPOSITION` | `REGULATE_GATE` | sets gate posture; `ADMIT` carries an expiring, non-reserving offer |
| `ENTER` | addressed participant | atomically accepts consequence and reserves work plus resolution units |
| `CHECKPOINT_DEPARTURE` | currently entered participant | binds the current entry to a deterministic departure-state succession without exiting |
| `REENTER` | returning addressed participant | consumes one sealed checkpoint after fresh presentation/admission and reserves a new lifecycle |
| `OBSERVE_CROSSING` | entered participant or active authority | records Matter crossing only |
| `MATTER_DISPOSITION` | entered participant or active authority | records that actor’s local posture only |
| `RECORD_EMERGENCE` | `RECORD_EMERGENCE` | records field-local emergence after contributor and Matter checks |
| `CORRECT` | actor of target event | appends correction without erasure |
| `EXIT` | currently entered participant | seals its named departure checkpoint, ends Presence, and releases lifecycle capacity |
| `CLOSE` | `CLOSE_LOCUS` | requires/seals participant checkpoints, closes locus, releases reservations, creates addressed residues |
| `INCORPORATE_ADDRESSED_RESIDUE` | `INCORPORATE_RESIDUE` | incorporates only a cryptographically matching residue addressed here |
| `DECLARE_CAPACITY` | `DECLARE_CAPACITY` | updates signed local `C_actual`; proves no external resource fact |
| `PULSE` | `PULSE` | commits exact prior state, posture, Presence count, capacity, time, and carrier-set digest |
| `RECLAIM_ADMISSION_OFFER` | `RECLAIM_ADMISSION_OFFER` | expires only a matching unentered offer after its deadline |
| `REGISTER_CONTINUITY_AUTHORITY` | active formation authority | registers a new bounded key and capabilities |
| `EXHAUST_FORMATION_AUTHORITY` | active formation authority | irreversibly ends formation privileges after continuity checks |
| `PROPOSE_SUCCESSOR` | `PROPOSE_SUCCESSOR` | records a successor candidate only |
| `ATTEST_SUCCESSOR` | continuity authority with `ATTEST_SUCCESSOR` | appends one exact-proposal attestation |
| `ACTIVATE_SUCCESSOR` | continuity authority with `ACTIVATE_SUCCESSOR` | freezes predecessor at a threshold-attested `P=0` boundary |

## Capacity semantics

An `ADMIT` payload requires positive `work_units`, positive `resolution_units`, and `offer_expires_at`. Every non-`ADMIT` posture requires all three fields to be zero.

The offer must be individually possible within the locus ceiling after preserving the global correction/egress reserve. It may still lose a race with another entry: admission is permission to attempt entry, not a promise of current capacity.

`ENTER` is all-or-nothing. It never partially reserves a consequence.

## Departure and renewed ingress

`CHECKPOINT_DEPARTURE` names the current entry and presentation, the state commitment carried on entry, zero to 128 ordered succession steps, and the resulting departure-state commitment. Each step contains only `delta_sha256` and the deterministically derived `successor_state_commitment`; private state and private deltas remain off chain. An empty passage is valid only when the departure commitment is unchanged.

`EXIT` must name that entry’s `OPEN` checkpoint. `CLOSE` refuses any present entry without one. Either motion seals it. Closure residue commits the participant, presentation, entry, checkpoint, and departure-state commitment.

`REENTER` is renewed ingress, not restoration. It names a fresh presentation, the ended prior entry, its `SEALED` checkpoint, the exact residue when the prior locus is closed, and a deterministic passage to the freshly presented state commitment. It also requires a fresh current `ADMIT`. Acceptance consumes the checkpoint exactly once and creates a distinct entry; the prior locus and history remain unchanged.

## Pulse construction

The pulse commitment binds this canonical envelope:

```json
{
  "schema": "LOCALITY_CURRENTNESS_002",
  "previous_state_commitment": "<accepted state>",
  "observed_at": 0,
  "presence_count": 0,
  "posture": "DORMANT_P0",
  "capacity": {},
  "carrier_set_sha256": "<digest>"
}
```

Use `GET /currentness?observed_at=...&carrier_set_sha256=...` to obtain the exact commitment for the accepted state. It becomes stale if any preceding transition changes state.

## Failure posture

Invalid motion returns an error and makes no state change. `HOLD` is an explicit gate posture or a capacity-derived body posture; it is not silent decision, refusal, or erasure.
