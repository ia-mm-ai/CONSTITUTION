# Qualification contract

The repository contains production-intent `LOCALITY_VM_002` source, but source presence is not deployment evidence. A commit is deployable only after its own qualification workflow passes. Evidence from either predecessor or an earlier binary does not transfer.

## Required automated gates

The `Qualify LOCALITY VM 002` GitHub workflow must pass on the exact commit to be released:

1. repository structure, JSON, shell, Python, manifest, and private-material checks;
2. Go unit and integration tests;
3. race detector;
4. `go vet`;
5. native Linux amd64 VM build;
6. exact AvalancheGo `v1.15.0` annotated-tag dereference to commit `70bd6d063b7343fd2cd8217200aaf77b57f19f68`;
7. reproducible application of `LOCALITY_SECURITY_OVERLAY_001` and its exact module-file digests;
8. zero reachable vulnerabilities reported by pinned `govulncheck@v1.7.0` for both the VM and overlaid AvalancheGo node;
9. three-validator disposable network bootstrap;
10. complete lifecycle execution, including departure checkpoint and carried-state renewed ingress;
11. living-capacity reservation, deficit/HOLD, exit release, and `P=0` dormancy tests;
12. finite formation-authority and threshold-attested succession-freeze tests;
13. equal accepted state on all three validators;
14. full-network restart replay;
15. one-validator stop, restart, and exact-state rejoin;
16. adversarial rejection of direct-entry bypass, broken commitment passage, wrong residue, checkpoint-free departure, and checkpoint reuse.

The workflow publishes public evidence only. Disposable locality authorities and validator credentials remain in a private temporary directory and are destroyed after the run.

The qualified compatibility identity is `v1.15.0+LOCALITY_SECURITY_OVERLAY_001`, not an unmodified `v1.15.0` node. The overlay is a bounded dependency-only delta whose input and output `go.mod`/`go.sum` digests are committed in `compat/AVALANCHEGO_SECURITY_OVERLAY_001.json`.

## Deployment gates not automated here

Before Mainnet formation, the operator must additionally complete:

- independent Go, Avalanche consensus, and cryptographic review;
- Fuji rehearsal with persisted validator credentials;
- restoration of those credentials onto a clean host while preserving the exact NodeID;
- partition, conflicting-block, validator replacement, resource-limit, API-abuse, and state-growth tests;
- network exposure, observability, backup, incident response, and upgrade procedures;
- independent custody and restoration tests for the formation key and at least two continuity keys;
- a deliberate operational procedure for successor proposals, attestations, and external binary handoff.

## Release meaning

Version `2.1.0` is the current protocol artifact identity; `2.0.0` remains its immutable qualified predecessor. Neither certifies any particular deployment, operator, validator, or chain. A GitHub release is admissible only when the release workflow re-runs the automated gates on that exact tag.
