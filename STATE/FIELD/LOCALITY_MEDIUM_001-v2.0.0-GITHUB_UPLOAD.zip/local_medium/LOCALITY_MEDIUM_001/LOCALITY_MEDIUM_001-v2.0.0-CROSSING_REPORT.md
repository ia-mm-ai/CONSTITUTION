# LOCALITY_MEDIUM_001 v2.0.0 — succession report

Sealed at `2026-09-21T15:56:24Z`.

## Outcome

`LOCALITY_MEDIUM_001 v1.0.0` was found intact, not malformed. Its six public
artifacts are byte-identical to the locally held release and lawfully describe
the VM002-bound historical medium. They have not been edited or replaced.

`LOCALITY_MEDIUM_001 v2.0.0` is the append-only successor. The common
Body/local-medium contract and its human, AI, device and locality embodiments
remain one bounded capability membrane. The major version changes its exact
consensus coupling from `LOCALITY_VM_002 v2.1.0` to `LOCALITY_VM_003 v3.0.0`.

## Public Source origin

- Repository: `https://github.com/ia-mm-ai/CONSTITUTION`
- Canonical Source commit:
  `4cf5a926d5fece4e3cccfdfcab40e16431dd332b`
- Human Form SHA-256:
  `5dea16e2400c652eb063129711a6bf26c8485a2cbad25ce261beda6f7fee5206`
- Machine Form SHA-256:
  `5a0d6ffec23d09b203212b295d86e45e141a33a7f35f525d56172fb848d1a73c`
- Form binding SHA-256:
  `cc2f4f2a1fdfab3287ee661dfbcc6e9db72c8e2ac918a94c288598f27916e758`
- Machine quotations verified against the human Form: `281/281`

The mirrored Forms and `FORM_BINDING.json` are exact. Their binding establishes
byte identity and relation only. It creates no adoption, applicability,
Authority, agency, autonomy, legitimacy, execution, deployment, formation,
succession, jurisdiction, or external currentness.

## Direct predecessor preservation

- Protocol and version: `LOCALITY_MEDIUM_001 v1.0.0`
- Clean public predecessor commit:
  `0bd963f46d447d0e41d494c6a782c1c2db9246e8`
- Repository pack SHA-256:
  `96007f0ffe089490d937e6dce18a225debedb521f86bfd2b323f6f2cc09bcdf2`
- Runtime pack SHA-256:
  `3eeb66308fc53994c17c632240daa565e53291787d8335460f07c47ae3f2d76a`
- Source archive SHA-256:
  `5d4104a74cfe379d8aab8c926b656932fc267f858cac4a1f08d345a62756c4da`
- Qualification evidence SHA-256:
  `05daaea21a45c21c18893c5f92d2eda535268a4dd76cc2dfba008c08a2b10280`
- Crossing report SHA-256:
  `4e7be98376549f49c19c5a9888c37d879e09f3389c33e13bf79480d59c961d47`
- SHA256SUMS SHA-256:
  `54a4eaea6ab55fecd0fba193cc0f5d9a654d319376138bf2b7f18c65d4a804f6`
- Disposition: `PRESERVED_BYTE_IDENTICAL`

## Consensus predecessor

- Protocol and version: `LOCALITY_VM_003 v3.0.0`
- Repository pack SHA-256:
  `5597eab61802b1df92636b6df88fea46b88f460c4e5f2c51e393c5c6ce7a214f`
- VM ID:
  `25tZjky6SecZA1Gwc6VwD2ouy64xAUdgNLo1C8dkXfbsFNxaTk`
- RPCChainVM protocol: `46`
- State schema: `LOCALITY_RUNTIME_STATE_003`
- Transition schema: `LOCALITY_TRANSITION_003`
- Receipt schema: `LOCALITY_RECEIPT_003`
- Continuity step schema: `LOCALITY_PARTICIPANT_STATE_SUCCESSION_003`
- Continuity passage schema: `LOCALITY_PARTICIPANT_STATE_PASSAGE_003`
- Form: `LOCALITY-FORM-003`
- Form SHA-256:
  `10848ac3fc2f68f6fdc041a4c9862d8fb186f4c3d0ebd4edde3f3933fe3ce893`
- Mutation: `NONE`

## Qualification

- Environment: Linux `6.18.44` x86_64, Node.js `v24.19.0`.
- Strict source, contract, profile and manifest verification: `PASS`.
- Adversarial and compatibility tests: `20/20 PASS`.
- Public Source and Form-pair binding: `PASS`.
- Published v1.0.0 predecessor identity: `PASS`.
- VM003 repository and wire-schema identities: `PASS`.
- Compatibility with VM003's canonical revision-18 state after full restart and
  single-validator rejoin: `PASS`.
- Carried-state renewed entry derived by the Medium as `PRESENT`: `PASS`.
- Line coverage: `86.65%`.
- Branch coverage: `58.63%`.
- Function coverage: `84.78%`.
- Third-party runtime dependencies: `0`.
- Secret-bearing artifacts: `0`.

The deployment-specific live successor-L1 passage remains intentionally open.
No Mainnet, Fuji, validator, wallet, production signer, or public chain was
created or mutated by this qualification.

## Sealed v2.0.0 artifacts

- GitHub repository pack — SHA-256
  `0962405082e8e07f428605a3091ac2307c921d2632f95ad62dea713103c84e70`
- Dependency-free runtime pack — SHA-256
  `e493b5a8383918c63c957dbfd14ed8d0a3e538cdde047af41da88dbe9771ef43`
- Deterministic source archive — SHA-256
  `904df60003cd1cdaa3ddec54241499e10d9d54abecd552efcf5135ad91012316`
- Qualification evidence — SHA-256
  `c7aba43baafa41374d75e7563e6079a1feff097904c08d8c84e7792d256a521c`

The repository's internal `MANIFEST.sha256` covers `54` source files and has
SHA-256
`c557dfa1d697becdccb9d6551c67ac91162a9f765a08a98b0196ebbdc41ed442`.
