import test from "node:test";
import assert from "node:assert/strict";
import { buildPassage, passageCommitment, successorStateCommitment } from "../src/continuity.js";

test("continuity commitment matches independent frozen vector", () => {
  const participant = `LOCALITY-ACTOR-${"a".repeat(40)}`;
  const from = "0".repeat(64);
  const delta = "1".repeat(64);
  const successor = successorStateCommitment(participant, from, delta, 1);
  assert.equal(successor, "6ff08ba75754d47afe752e30c48ea7bbd3ff105964b527efa488363f8ea6d7a5");
  const built = buildPassage(participant, from, [delta]);
  assert.equal(built.result_state_commitment, successor);
  assert.equal(
    passageCommitment(participant, from, built.passage, successor),
    "fc8af8b7844661ce8db33e5849a7b0066c4b9d75c22b15dcd35ef66b23763823"
  );
});

test("continuity passage refuses a broken successor edge", () => {
  assert.throws(() => passageCommitment(
    "PARTICIPANT-001",
    "0".repeat(64),
    [{ delta_sha256: "1".repeat(64), successor_state_commitment: "2".repeat(64) }],
    "2".repeat(64)
  ), /does not succeed/);
});
