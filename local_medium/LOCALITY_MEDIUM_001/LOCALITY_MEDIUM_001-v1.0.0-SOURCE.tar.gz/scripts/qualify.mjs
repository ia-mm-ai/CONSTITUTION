import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import process from "node:process";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const artifacts = resolve(root, "artifacts");
await mkdir(artifacts, { recursive: true });

function run(command, args) {
  const result = spawnSync(command, args, { cwd: root, encoding: "utf8" });
  return {
    command: [command, ...args].join(" "),
    status: result.status,
    stdout: result.stdout,
    stderr: result.stderr
  };
}

function sha256(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

const syntaxAndContract = run(process.execPath, ["./scripts/verify.mjs"]);
const tests = run(process.execPath, ["--test", "test/cli.test.js", "test/config.test.js", "test/continuity.test.js", "test/engine.test.js", "test/journal.test.js", "test/profile.test.js", "test/server.test.js", "test/state.test.js", "test/vm-client.test.js"]);
const coverage = run(process.execPath, ["--test", "--experimental-test-coverage", "test/cli.test.js", "test/config.test.js", "test/continuity.test.js", "test/engine.test.js", "test/journal.test.js", "test/profile.test.js", "test/server.test.js", "test/state.test.js", "test/vm-client.test.js"]);
const kernel = run("uname", ["-srm"]);

let predecessor = { supplied: false, expected_sha256: "bffc125a5873a42b8ad81ede898ae7d65e36666870af3f0e6e6e5d7bdf2ddacb" };
if (process.env.LOCALITY_MEDIUM_PREDECESSOR_PACK) {
  const path = resolve(process.env.LOCALITY_MEDIUM_PREDECESSOR_PACK);
  const digest = sha256(await readFile(path));
  predecessor = {
    supplied: true,
    filename: path.split("/").at(-1),
    expected_sha256: predecessor.expected_sha256,
    observed_sha256: digest,
    exact: digest === predecessor.expected_sha256
  };
}

const passed = syntaxAndContract.status === 0 && tests.status === 0 && coverage.status === 0 && (!predecessor.supplied || predecessor.exact);
const report = {
  schema: "LOCALITY_MEDIUM_QUALIFICATION_001",
  protocol: "LOCALITY_MEDIUM_001",
  version: "1.0.0",
  qualified: passed,
  environment: {
    node: process.version,
    platform: process.platform,
    architecture: process.arch,
    kernel: kernel.stdout.trim()
  },
  predecessor,
  gates: {
    syntax_contract_profiles_manifest: syntaxAndContract.status === 0 ? "PASS" : "FAIL",
    adversarial_tests: tests.status === 0 ? "PASS" : "FAIL",
    coverage_run: coverage.status === 0 ? "PASS" : "FAIL",
    live_successor_l1_coupling: "NOT_RUN_DEPLOYMENT_SPECIFIC"
  },
  claim_ceiling: "REFERENCE_IMPLEMENTATION_QUALIFIED_LIVE_SUCCESSOR_COUPLING_REQUIRED"
};

await writeFile(resolve(artifacts, "LOCALITY_MEDIUM_001-v1.0.0-qualification.json"), `${JSON.stringify(report, null, 2)}\n`, { mode: 0o644 });
await writeFile(resolve(artifacts, "LOCALITY_MEDIUM_001-v1.0.0-tests.txt"), `${tests.stdout}${tests.stderr}`, { mode: 0o644 });
await writeFile(resolve(artifacts, "LOCALITY_MEDIUM_001-v1.0.0-coverage.txt"), `${coverage.stdout}${coverage.stderr}`, { mode: 0o644 });
await writeFile(resolve(artifacts, "LOCALITY_MEDIUM_001-v1.0.0-verification.txt"), `${syntaxAndContract.stdout}${syntaxAndContract.stderr}`, { mode: 0o644 });

process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
if (!passed) process.exitCode = 1;
