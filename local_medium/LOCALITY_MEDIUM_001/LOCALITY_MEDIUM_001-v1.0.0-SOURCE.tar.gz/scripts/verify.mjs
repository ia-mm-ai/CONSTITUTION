import { createHash } from "node:crypto";
import { lstat, readFile, readdir } from "node:fs/promises";
import { dirname, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { validateProfile } from "../src/profile.js";
import {
  MEDIUM_CONTRACT_SCHEMA,
  MEDIUM_PROTOCOL,
  MEDIUM_VERSION,
  VM_FORM_ID,
  VM_FORM_SHA256,
  VM_ID,
  VM_REPOSITORY_SHA256,
  VM_RPCCHAINVM_PROTOCOL,
  VM_VERSION
} from "../src/constants.js";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");

function sha256(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

async function walk(directory) {
  const result = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (entry.name === ".git" || entry.name === "node_modules" || entry.name === "artifacts") continue;
    const path = resolve(directory, entry.name);
    const info = await lstat(path);
    if (info.isSymbolicLink()) throw new Error(`symbolic link is forbidden in release source: ${relative(root, path)}`);
    if (info.isDirectory()) result.push(...await walk(path));
    else if (info.isFile()) result.push(path);
  }
  return result.sort();
}

function requireEqual(actual, expected, label) {
  if (actual !== expected) throw new Error(`${label}: expected ${expected}, got ${actual}`);
}

function runNode(args, label) {
  const result = spawnSync(process.execPath, args, { cwd: root, encoding: "utf8" });
  if (result.status !== 0) throw new Error(`${label} failed\n${result.stdout}${result.stderr}`);
  return result.stdout;
}

const files = await walk(root);
const forbiddenNames = new Set(["staker.key", "signer.key", "private.key", "id_rsa", "id_ed25519"]);
for (const path of files) {
  const name = path.split("/").at(-1).toLowerCase();
  if (forbiddenNames.has(name) || /\.(pem|p12|pfx|key)$/.test(name)) {
    throw new Error(`secret-bearing filename is forbidden: ${relative(root, path)}`);
  }
  if (/\.(js|mjs)$/.test(path)) runNode(["--check", path], `syntax ${relative(root, path)}`);
  if (path.endsWith(".json")) {
    const value = JSON.parse(await readFile(path, "utf8"));
    const searchKeys = (node) => {
      if (!node || typeof node !== "object") return;
      for (const [key, child] of Object.entries(node)) {
        if (["private_key", "mnemonic", "seed_phrase"].includes(key.toLowerCase())) {
          throw new Error(`forbidden secret field in ${relative(root, path)}`);
        }
        searchKeys(child);
      }
    };
    searchKeys(value);
  }
}

const packageDocument = JSON.parse(await readFile(resolve(root, "package.json"), "utf8"));
requireEqual(packageDocument.version, MEDIUM_VERSION, "package version");
if (packageDocument.dependencies || packageDocument.devDependencies) throw new Error("third-party package dependencies are not permitted");

const contract = JSON.parse(await readFile(resolve(root, "contract/LOCALITY_MEDIUM_CONTRACT_001.json"), "utf8"));
requireEqual(contract.schema, MEDIUM_CONTRACT_SCHEMA, "contract schema");
requireEqual(contract.version, MEDIUM_VERSION, "contract version");
requireEqual(contract.medium_protocol, MEDIUM_PROTOCOL, "contract protocol");
requireEqual(contract.predecessor.version, VM_VERSION, "predecessor version");
requireEqual(contract.predecessor.vm_id, VM_ID, "predecessor VM ID");
requireEqual(contract.predecessor.rpcchainvm_protocol, VM_RPCCHAINVM_PROTOCOL, "predecessor RPC protocol");
requireEqual(contract.predecessor.form_id, VM_FORM_ID, "predecessor form ID");
requireEqual(contract.predecessor.form_sha256, VM_FORM_SHA256, "predecessor form digest");
requireEqual(contract.predecessor.repository_pack_sha256, VM_REPOSITORY_SHA256, "predecessor pack digest");
requireEqual(contract.predecessor.mutation, "NONE", "predecessor mutation");

const kinds = [];
for (const reference of contract.reference_profiles) {
  const path = resolve(root, reference.path);
  const bytes = await readFile(path);
  requireEqual(sha256(bytes), reference.file_sha256, `${reference.profile_id} digest`);
  const profile = validateProfile(JSON.parse(bytes.toString("utf8")));
  requireEqual(profile.profile_id, reference.profile_id, "profile ID");
  requireEqual(profile.embodiment_kind, reference.embodiment_kind, "profile kind");
  kinds.push(profile.embodiment_kind);
}
requireEqual([...new Set(kinds)].sort().join(","), "AI,DEVICE,HUMAN,LOCALITY", "reference profile kinds");

const predecessor = JSON.parse(await readFile(resolve(root, "lineage/PREDECESSOR_LOCK.json"), "utf8"));
requireEqual(predecessor.predecessor_repository_pack_sha256, VM_REPOSITORY_SHA256, "lineage pack digest");
requireEqual(predecessor.predecessor_mutation, "NONE", "lineage mutation");

const release = JSON.parse(await readFile(resolve(root, "RELEASE_MANIFEST.json"), "utf8"));
requireEqual(release.release.protocol, MEDIUM_PROTOCOL, "release protocol");
requireEqual(release.release.version, MEDIUM_VERSION, "release version");
requireEqual(release.predecessor.mutation, "NONE", "release predecessor mutation");
for (const [name, artifact] of Object.entries(release.bound_artifacts)) {
  requireEqual(sha256(await readFile(resolve(root, artifact.path))), artifact.sha256, `release artifact ${name}`);
}

const testFiles = files.filter((path) => path.endsWith(".test.js"));
const testOutput = runNode(["--test", ...testFiles], "test suite");

const manifestPath = resolve(root, "MANIFEST.sha256");
if (files.includes(manifestPath)) {
  for (const line of (await readFile(manifestPath, "utf8")).trim().split("\n")) {
    const match = /^([0-9a-f]{64})  (.+)$/.exec(line);
    if (!match) throw new Error("MANIFEST.sha256 contains a malformed line");
    const path = resolve(root, match[2]);
    requireEqual(sha256(await readFile(path)), match[1], `manifest ${match[2]}`);
  }
}

process.stdout.write(`${JSON.stringify({
  verified: true,
  protocol: MEDIUM_PROTOCOL,
  version: MEDIUM_VERSION,
  source_files_checked: files.length,
  reference_profiles: kinds.length,
  tests: (testOutput.match(/^✔/gm) ?? []).length,
  predecessor_mutated: false
}, null, 2)}\n`);
