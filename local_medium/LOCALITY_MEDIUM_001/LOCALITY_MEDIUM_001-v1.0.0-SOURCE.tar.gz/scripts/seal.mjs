import { createHash } from "node:crypto";
import { lstat, readFile, readdir, writeFile } from "node:fs/promises";
import { dirname, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");

async function walk(directory) {
  const files = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if ([".git", "node_modules", "artifacts"].includes(entry.name)) continue;
    const path = resolve(directory, entry.name);
    const info = await lstat(path);
    if (info.isSymbolicLink()) throw new Error(`refusing symbolic link ${relative(root, path)}`);
    if (info.isDirectory()) files.push(...await walk(path));
    else if (info.isFile() && entry.name !== "MANIFEST.sha256") files.push(path);
  }
  return files;
}

const lines = [];
for (const path of (await walk(root)).sort()) {
  const digest = createHash("sha256").update(await readFile(path)).digest("hex");
  lines.push(`${digest}  ${relative(root, path)}`);
}
await writeFile(resolve(root, "MANIFEST.sha256"), `${lines.join("\n")}\n`, { mode: 0o644 });
process.stdout.write(`${JSON.stringify({ sealed: true, files: lines.length })}\n`);
