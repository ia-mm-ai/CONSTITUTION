# Common adapter contract

## Jurisdictions

`LOCALITY_VM_002` is the deterministic public law. It decides whether a signed
transition changes accepted locality state. `LOCALITY_MEDIUM_001` is an
executable membrane. It converts a fresh accepted state into one bounded grant
for a controlled external surface. A Body/runtime retains private memory,
processes, tools, sensors, and signer custody and bears the local consequence.

No layer may silently claim the jurisdiction of another.

## Decision equation

A capability is locally grantable only when all terms are true:

```text
profile allows capability
AND accepted phase allows capability
AND accepted actor/key binding is coherent
AND state commitment is current
AND no transition is pending
AND predecessor is not frozen at succession
AND the operation remains within the VM's own authority law
```

Denial is the default. A decision is bound to one accepted state commitment; it
is not a lease across future state. The broker performs a fresh decision for
every invocation.

## Conformance is not authority

The VM requires every `PRESENT_FORM` payload to declare the complete local-medium
protocol surface. That declaration means the presented form understands the
protocol. It does not grant the actor every host operation. The selected
reference profile narrows the surface, accepted authority state narrows it
again, and the VM remains final.

## Signer boundary

This process accepts only a public key. It never loads, generates, stores, or
transmits a private key. It asks the VM for an exact unsigned draft, commits the
draft and signing bytes to its journal, and accepts a signature from an external
protected Ed25519 signer. Before submission it verifies the signature, public
key, actor derivation, live draft, operation, and predecessor state commitment.

## Evidence boundary

The journal contains capability decisions, public state commitments, payload
digests, transition IDs, and accepted receipt commitments. It contains neither
payload contents nor private state. A receipt proves a past accepted local
consequence; it is not current Presence or evidence of behavior outside the
controlled surface.

## Fail-closed conditions

The medium refuses capability or transition flow when:

- `/status` and `/state` are incoherent;
- the VM, VM ID, form, RPC protocol, chain route, or locality differs from the
  configured identity;
- any numeric value used by the JavaScript runtime cannot be represented safely;
- another transition is pending;
- the accepted actor key differs from the configured public key;
- a signed transition differs from the exact live draft;
- the accepted state changed after drafting;
- the selected profile or accepted phase omits the capability;
- capacity is in HOLD, except the profile's correction/egress path;
- the predecessor is frozen at an explicit succession boundary.

Process restart discards live drafts by design.
