# Embodiment reference profiles

The four profiles share one law and differ only in the medium that can bear a
local capability. They are operational adapter profiles, not ontological
classes.

## Human

`HUMAN_MEDIUM_001` is appropriate when a human uses an application or wallet
whose locality-facing operations pass through the broker. After accepted entry,
the application may open its human locality channel and prepare participant
operations. After departure checkpoint, the channel closes and only correction
and exit remain.

Example: a participant presents a form commitment, is admitted for two capacity
units, enters, observes a document commitment, chooses a local matter posture,
checkpoints a private working-state commitment, and exits. The document and
private working state remain outside the chain.

## AI

`AI_MEDIUM_001` controls a supervised AI tool broker and locality channel. The
model or agent may reason privately, but locality tools are callable only while
the accepted entry is `PRESENT`. A checkpoint, exit, capacity HOLD, state
mismatch, or explicit succession removes tool access before the next call.

Example: an agent enters with a carried state commitment, receives one bounded
repository-read tool through the broker, produces a delta commitment, and
checkpoints the resulting successor. The medium does not claim the runtime is
conscious, identical to an earlier runtime, or obedient outside the broker.

## Device

`DEVICE_MEDIUM_001` controls an inspectable command gateway and observation
commitment path. A sensor reading can be committed as Matter; the raw reading
need not be public. Device commands are admitted only through the broker while
the device's entry is present.

Example: an environmental device enters a temporary locus, commits the digest
of a measurement batch, receives one bounded sampling command, then checkpoints
and exits. Unrouted firmware behavior is outside the medium's claim.

## Locality

`LOCALITY_MEDIUM_001` can mediate a locality as a participant in another
locality and can be selected for a host gateway whose signing actor has accepted
host authority. The profile does not create that authority; VM state must
already contain it.

Example: a derivative locality presents its state commitment to a host,
receives a fresh capacity-bounded admission, crosses an addressed residue, and
later exits carrying a successor commitment. Alternatively, the host gateway
may gate or close a locus only when its configured actor has the corresponding
accepted authority.

## Extending a profile

A production profile may narrow a reference profile. Expanding one is a new
reviewed profile artifact with a new digest. It must preserve the full effect
ceiling, protected signer boundary, private-state custody rule, all phases, and
the common denial semantics. Never edit a deployed profile in place.
