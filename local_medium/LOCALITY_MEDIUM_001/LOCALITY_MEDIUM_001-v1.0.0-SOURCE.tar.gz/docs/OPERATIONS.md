# Operating the medium

## Before activation

1. Verify the repository and release checksums.
2. Confirm the target L1 actually runs `LOCALITY_VM_002 v2.1.0`, VM ID
   `2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5`, on RPCChainVM `46`.
3. Set `expected_blockchain_id` to the new successor L1, not KENTRA's completed
   predecessor chain.
4. Set `expected_locality_id` to the immutable locality ID in that L1 genesis.
5. Select one reviewed profile and verify its digest against the common contract.
6. Put the Ed25519 private key in an external protected signer. Configure only
   its public key and derived actor ID here.
7. Keep the append-only journal on storage writable only by the service account.

## Run topology

Run the medium on the same trusted host as AvalancheGo or on a separate host over
authenticated HTTPS. Its own HTTP interface is loopback-only; expose it to an
application through a local reverse proxy only if that proxy supplies the
required authentication and request controls.

Do not make `/v1/authorize` an advisory pre-check followed by a direct tool call.
The tool itself must be behind `CapabilityBroker.invoke`, so the accepted state
is checked immediately at execution.

## Transition passage

1. Application sends an operation payload to `/v1/drafts`.
2. Medium fetches fresh accepted state and applies the selected profile.
3. VM returns an exact unsigned transition.
4. Medium verifies the draft and returns its commitment and signing digest.
5. External signer signs that exact object.
6. Application sends the signed transition to `/v1/transitions` in the same
   running process.
7. Medium fetches fresh accepted state again, verifies signature and draft, and
   submits it.
8. Application waits for `/v1/receipts/<id>`. Only an accepted receipt is a
   consequence.

If any state changed between steps, discard the draft and begin again.

## Back up

Back up configuration without secrets, selected profile, common contract,
journal, release manifest, and checksums. The journal is evidence, not private
state recovery. Participant-held state and its delta material need their own
custody and backup regime.

## Upgrade

Never overwrite the running profile, contract, or release pack. Introduce a new
version, qualify it against the still-frozen predecessor, and activate it at an
explicit boundary. `LOCALITY_VM_002 v2.1.0` already contains the successor law;
use that law when the VM itself must evolve.
