# Qualification

`LOCALITY_MEDIUM_001 v1.0.0` is qualified as a dependency-free reference
implementation of the Body/local-medium contract.

The repository gate requires:

- JavaScript syntax validation for every source, test, example and script;
- all four reference profiles validated against one strict profile schema;
- every profile byte digest matched to the common contract;
- exact predecessor pack, VM ID, VM version, RPC protocol, form ID and form
  digest binding;
- deterministic continuity vectors matching the VM's Go JSON field order;
- state-phase and capacity-HOLD tests;
- tool broker revocation after exit;
- protected-signer draft/sign/submit verification;
- stale-state and altered-signature rejection;
- append-only journal tamper detection;
- absence of third-party packages, symlinks and secret-bearing artifacts.

This qualification does not claim live successor-L1 coupling. Before production
activation, deploy the unchanged VM on the successor L1, point the medium at its
real chain route, and exercise presentation, admission, entry, capability use,
departure checkpoint, exit and carried-state re-entry with the production signer
and selected profile. That is deployment qualification, not a reason to mutate
this contract.
