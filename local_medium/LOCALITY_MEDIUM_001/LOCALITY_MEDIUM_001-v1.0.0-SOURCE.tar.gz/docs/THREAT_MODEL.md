# Threat model

## Protected properties

- exact binding to one chain route, VM, locality, form, actor and accepted state;
- no capability grant after the state or participant phase changes;
- no private signing material in process, configuration, journal, or release;
- no private participant-state content in consensus or local evidence;
- append-only correction and continuity commitments;
- no elevation from protocol conformance to host authority.

## Refused threats

- stale authorization reuse;
- altered unsigned payload after authorization;
- signer substitution or actor/public-key mismatch;
- operation use outside the selected profile;
- tool use before entry or after checkpoint/exit;
- new substantive work during capacity deficit through reference participant
  profiles;
- continuation based on key identity without carried state succession;
- continued operation after explicit VM succession;
- plaintext remote VM endpoints;
- overbroad journal permissions;
- response amplification beyond configured limits.

## Residual risks

The medium cannot constrain an operation that bypasses its broker. It cannot
prove an external runtime executed a granted action faithfully. It trusts the
host operating system, Node.js runtime, network/TLS termination, AvalancheGo,
the deployed VM binary, protected signer, and the integrity of the configured
profile. A compromised host can suppress service or forge local journal data
after compromise; publish journal heads externally if independent chronology is
required.

The service has no user-authentication layer because it binds to loopback.
Production multi-user access requires an authenticated local application or
reverse proxy. Do not expose it directly to a public network.

JavaScript cannot exactly represent integers larger than `2^53 - 1`. The medium
fails closed for safety-relevant values outside that range. If a deployment
needs larger capacity or revision values, the next implementation must use an
exact-integer JSON representation agreed with the VM.
