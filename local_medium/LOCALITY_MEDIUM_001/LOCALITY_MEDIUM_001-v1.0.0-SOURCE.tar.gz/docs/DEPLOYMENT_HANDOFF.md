# Deployment handoff

## Immutable release inputs

- `LOCALITY_MEDIUM_001 v1.0.0`
- `LOCALITY_VM_002 v2.1.0` repository pack SHA-256
  `bffc125a5873a42b8ad81ede898ae7d65e36666870af3f0e6e6e5d7bdf2ddacb`
- VM ID `2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5`
- RPCChainVM protocol `46`

## Deployment-specific inputs

- successor Mainnet L1 blockchain ID;
- successor genesis locality ID;
- AvalancheGo endpoint and TLS boundary;
- one selected profile digest;
- actor public key and derived actor ID;
- protected signer implementation;
- journal location and backup policy;
- actual capability handlers placed behind `CapabilityBroker`.

## Required first live passage

1. Verify `/health` reports exact VM and locality identities.
2. Present the selected form with the complete protocol declaration and effect
   ceiling.
3. Have a distinct host authority issue a capacity-bounded admission.
4. Enter and invoke exactly one harmless, observable brokered capability.
5. Commit a participant-held departure state.
6. Exit and verify the broker refuses the capability.
7. Open a new locus, freshly present and admit, then re-enter with a deterministic
   carried-state succession passage.
8. Verify the checkpoint is consumed once and the broker reopens only on the new
   accepted entry.

Keep the full receipts, journal head, state commitments and deployment descriptor.
Never include signer material or private participant state in that evidence.
