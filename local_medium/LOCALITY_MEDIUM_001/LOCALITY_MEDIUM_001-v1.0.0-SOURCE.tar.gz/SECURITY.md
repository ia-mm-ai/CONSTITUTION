# Security

Do not report vulnerabilities by publishing live private keys, signer material,
participant state, or undisclosed chain-control details. Preserve the affected
release digest, contract digest, profile digest, VM ID, blockchain ID, accepted
state commitment, and the smallest non-secret reproduction.

Immediate containment for a suspected medium compromise is to stop the medium,
stop routing capabilities through it, protect the external signer, preserve the
journal, and inspect accepted chain state independently. Restarting invalidates
all in-process drafts but does not reverse accepted VM transitions.

The security boundary and residual risks are specified in
[`docs/THREAT_MODEL.md`](docs/THREAT_MODEL.md).
