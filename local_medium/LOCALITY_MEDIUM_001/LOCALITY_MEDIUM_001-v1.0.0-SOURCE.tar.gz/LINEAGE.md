# Lineage

`LOCALITY_MEDIUM_001 v1.0.0` is a companion successor layer to the unchanged
`LOCALITY_VM_002 v2.1.0` repository pack.

- Predecessor pack SHA-256:
  `bffc125a5873a42b8ad81ede898ae7d65e36666870af3f0e6e6e5d7bdf2ddacb`
- Predecessor VM ID:
  `2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5`
- Predecessor form:
  `LOCALITY-FORM-002.1`
- Predecessor form SHA-256:
  `c28a863265099ceb261fb25020911fbd172a71ff2211329a3a6ea8da8dbd26fd`
- Required RPCChainVM protocol: `46`

The predecessor is referenced, never copied into or rewritten by this release.
This layer makes its already-declared local-medium boundary executable and adds
no consensus operation.

The reference profiles are the first four bounded embodiments of one contract:
human, AI, device and locality. Their names indicate controlled media, not kinds
of consciousness, metaphysical identities, or ownership.
