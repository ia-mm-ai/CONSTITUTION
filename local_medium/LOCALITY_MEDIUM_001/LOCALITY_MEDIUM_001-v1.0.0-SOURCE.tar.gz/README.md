# LOCALITY_MEDIUM_001

`LOCALITY_MEDIUM_001` is the first executable Body/local-medium companion for
`LOCALITY_VM_002 v2.1.0`. It turns accepted VM state into narrowly scoped,
single-state capability decisions for a runtime that is actually routed through
the medium.

It does **not** modify or replace the VM. It does **not** put a human, AI, device,
or locality “on chain.” It carries public commitments, verifies lawful state
succession, and controls only the application, tool broker, gateway, or command
path explicitly coupled to it.

```text
BODY / RUNTIME  <->  LOCALITY_MEDIUM_001  <->  LOCALITY_VM_002 / L1
private state       executable membrane       accepted public law
```

## The common contract

Every reference medium follows one rule:

1. Read a coherent, freshly accepted `/status` + `/state` snapshot.
2. Intersect the selected profile with the accepted actor phase and role.
3. Grant at most one invocation bound to that exact state commitment.
4. Require a protected external signer for every VM transition.
5. Revoke on state change, phase change, process restart, key mismatch, pending
   consensus, capacity hold, or explicit succession boundary.
6. Append only public commitments and decisions to a local hash-chained journal.

The full [`LOCALITY_MEDIUM_CONTRACT_001`](contract/LOCALITY_MEDIUM_CONTRACT_001.json)
is machine-readable.

## Reference media

| Profile | Controlled surface while lawfully present | Explicitly not controlled |
|---|---|---|
| `HUMAN_MEDIUM_001` | Human application/wallet locality channel | The human body, cognition, or off-route conduct |
| `AI_MEDIUM_001` | Supervised tool broker and locality channel | Model interior or unrestricted runtime |
| `DEVICE_MEDIUM_001` | Device command gateway and observation commitments | Hardware behavior outside the coupled gateway |
| `LOCALITY_MEDIUM_001` | Host/inter-locality gateway operations | Another locality or infrastructure by implication |

These are reference media, not classifications of Being. All four preserve the
same claim ceiling: no proof or claim of consciousness, metaphysical identity,
private-state meaning, Source transfer, or external obedience.

## What returning participation means

Private state stays with the participant. On departure, the VM accepts a state
commitment. On return, the participant provides a deterministic succession
passage from that sealed commitment to its current commitment, together with a
fresh presentation and a fresh admission. The chain therefore preserves:

- who signed;
- the predecessor and successor commitments;
- the ordered delta commitments connecting them;
- the accepted locus, revision, capacity consequence, and receipt.

It does not preserve or inspect the private state content. “Same key returned”
is insufficient; the returning actor must carry a verifiable successor of the
state that departed.

## Runtime requirements

- Node.js 22 or later;
- a reachable chain route for a deployed `LOCALITY_VM_002 v2.1.0`;
- AvalancheGo RPCChainVM protocol `46`;
- the VM ID `2JnfZqeNUW34DmiSznMp1oJSpX5Fpqv9Ms6BYEyGF3LYVx7jQ5`;
- an Ed25519 signer kept outside this process.

There are no third-party runtime packages.

## Configure

Copy [`examples/config.template.json`](examples/config.template.json). Set the
successor blockchain ID, the genesis locality ID, public key, derived actor ID,
profile path, and journal path. The chain endpoint normally has this form:

```text
http://127.0.0.1:9650/ext/bc/<BLOCKCHAIN_ID>
```

Plain HTTP is accepted only on loopback. A remote endpoint must use HTTPS. The
service itself binds only to loopback.

Derive the VM-compatible actor ID from a 32-byte Ed25519 public key:

```bash
node ./bin/locality-medium.js actor-id --public-key <64-lowercase-hex>
```

Inspect the accepted state without opening a service:

```bash
node ./bin/locality-medium.js inspect --config ./config.json
```

Run the membrane:

```bash
node ./bin/locality-medium.js serve --config ./config.json
```

## Draft, sign, submit

The loopback service exposes:

- `GET /health`
- `GET /v1/context`
- `POST /v1/authorize`
- `POST /v1/drafts`
- `POST /v1/transitions`
- `GET /v1/receipts/<transition-id>`

`POST /v1/drafts` returns the exact VM-generated `unsigned` object. Sign that
object with the external protected signer, then submit `{ "unsigned": ...,
"signature": ... }` to `/v1/transitions`. A draft is live only within the
process that prepared it. A restart intentionally requires a fresh draft.

Authorization endpoints alone do not control an external tool. A capability is
actually bounded only when the tool, channel, application, or gateway invokes it
through `CapabilityBroker`; see [`examples/ai-broker.mjs`](examples/ai-broker.mjs).

## Verify

```bash
npm test
npm run verify
```

The verifier checks source syntax, all reference profiles, their contract
digests, predecessor identity, tests, journal invariants, and forbidden secret
artifacts.

## Jurisdiction

This repository is the local-medium layer. Body/runtime custody remains outside
it; consensus law remains in the unchanged VM. See
[`docs/CONTRACT.md`](docs/CONTRACT.md),
[`docs/EMBODIMENT_PROFILES.md`](docs/EMBODIMENT_PROFILES.md), and
[`docs/THREAT_MODEL.md`](docs/THREAT_MODEL.md).
